<?php
return
[
    'title' => 'Al Shehry',
    // blog // index
    'Share' => 'Share',
    // index // home
    'Since_We_Started' => 'Since We Started',
    'Our_Clients' => 'Our Clients',
    'Read_More' => 'Read More',
    'Read_More_News' => 'Read More News',
    'Connect_With' => 'Connect With',
    'Message' => 'Message',
    // index // profile
    'Email_not_verified' => 'Email not verified!',
    'Dashboard' => 'Dashboard',
    'Add_New_Subscription' => 'Add New Subscription',
    'Book' => 'Book',
    'Booking_Confirmed' => 'Booking Confirmed',
    'Mobile_Edit' => 'Mobile Edit',
    'SIGN_OUT' => 'SIGN OUT',
    'My_profile_information' => 'My profile information',
    'Full_Name' => 'Full Name',
    'Email' => 'Email',
    'Gender' => 'Gender',
    'My_Address' => 'My Address',
    'City' => 'City',
    'ِArea' => 'ِArea',
    'Full_Address' => 'Full Address',
    'My_Mobile_Phone' => 'My Mobile Phone',
    'Phone_Number' => 'Phone Number',
    'subscriber_system' => 'subscriber system',
    'select_subtype' => 'select subtype ...',
    'contact_with_company_to_reactive_your_account' => 'contact with company to reactive your account',
    'Logo' => 'Logo',
    'Name' => 'Name',
    'Phone' => 'Phone',
    'From' => 'From',
    'To' => 'To',
    'startsub' => 'Start',
    'endsub' => 'End',
    'this_is_book_is_waiting_to_confirm_contact_company_to_confirmed' => 'this is book is waiting to confirm contact company to confirmed',
    'theres_no_subscriber_in_your_book_add_subscriber_in_add_new_subsciption' => 'there\'s no subscriber in your book add subscriber in add new subsciption',
    'Invoice_Num' => 'Invoice Num',
    'you_have_new_book_subscription_please_contact_company_to_confirmed' => 'you have new book subscription please contact company to confirmed',
    'Reset_Your_Mobile' => 'Reset Your Mobile',
    'reset_phone' => 'reset phone',

    'send' => 'send',
    // layouts // navbar
    'Login' => 'Login',
    'Register' => 'Register',
    'Home' => 'Home',
    'About_us' => 'About us',
    'Blog' => 'Blog',
    'Contact_Us' => 'Contact_Us',
    'You_have' => 'You have',
    'Notifications' => 'Notifications',
    'this_subscriber_will_ended_soon_after' => 'this subscriber will ended soon after',
    // layouts // slider
    'ELSHEHRY' => 'ELSHEHRY',
    'HALF' => 'HALF',
    'MOON' => 'MOON',

    // profile // notiinfo
    'invoice_number' => 'invoice number',
    'invoice_date' => 'invoice date',
    'Now_Is_Active' => 'Now Is Active',
    // profile // subcreate_company
    'subsystem' => 'subsystem',
    'arabic_name' => 'Arabic Name',
    'english_name' => 'English Name',
    'cr_num' => 'cr num',
    'tax_num' => 'tax num',
    'per_status' => 'per_status',
    'addriss' => 'addriss',
    'depart' => 'depart',
    'desname' => 'desname',
    'mob' => 'mobile number',
    'phone' => 'phone number',
    'facebook' => 'facebook',
    'twitter' => 'twitter',
    'select' => 'Select ...',
    'you_can_t_add_more_than_one_company_if_you_want_more_connect_with_company' => 'you can\'t add more than one company if you want more connect with company',
    // profile // subcreate_signle
    'image' => 'image',
    'age' => 'age',
    'Job' => 'Job',
    'select_age' => 'select age ...',
    'You_can_not_add_more_than_one_subscriber_if_you_want_more_contact_with_company' => 'You can not add more than one subscriber if you want more contact with company',
    // profile // subcreate_student
    'School' => 'School',



    
];