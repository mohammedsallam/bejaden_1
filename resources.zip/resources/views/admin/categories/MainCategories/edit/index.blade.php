{{--First tap--}}
@include('admin.categories.MainCategories.create.cat_data')
{{--Second tap--}}
@include('admin.categories.MainCategories.create.weight_measure')
{{--third tap--}}
@include('admin.categories.MainCategories.create.purchases')
