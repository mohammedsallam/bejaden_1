<div class="tab-pane fade" id="weight_measure" role="tabpanel" aria-labelledby="home-tab">
    <div class="panel panel-default">
        <div class="panel-body">
            weight_measure
        </div>
    </div>
</div>
