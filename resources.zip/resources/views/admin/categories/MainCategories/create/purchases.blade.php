<div class="tab-pane fade" id="purchases" role="tabpanel" aria-labelledby="home-tab">
    <div class="panel panel-default">
        <div class="panel-body">
            purchases
        </div>
    </div>
</div>
