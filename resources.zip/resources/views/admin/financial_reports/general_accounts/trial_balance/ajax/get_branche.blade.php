{{--<script>--}}
{{--    $(function () {--}}
{{--        'use strict'--}}
{{--        $('.e2').select2({--}}
{{--            placeholder: "{{trans('admin.select')}}",--}}
{{--            dir: '{{direction()}}'--}}
{{--        });--}}
{{--    });--}}

{{--</script>--}}
{{--<script>--}}
{{--    $(function () {--}}
{{--        'use strict'--}}

{{--        $(".MainBranch").on("change",function(){--}}

{{--            $('.column-form').html('');--}}


{{--        });--}}
{{--        });--}}
{{--    </script>--}}
{{--<div>--}}
{{--    {{ Form::label('MainBranch','الفروع', ['class' => 'control-label']) }}--}}
{{--    {{ Form::select('MainBranch',$MainBranch,null, array_merge(['class' => 'form-control MainBranch  branch e2','placeholder'=> trans('admin.select') ])) }}--}}
{{--</div>--}}

