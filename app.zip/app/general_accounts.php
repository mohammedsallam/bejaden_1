<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class general_accounts extends Model
{
    //
}
