<?php

namespace App\Enums\dataLinks;

use BenSampo\Enum\Contracts\LocalizedEnum;
use BenSampo\Enum\Enum;

final class CCreporttype extends Enum implements LocalizedEnum
{
    const level = 0;
    const individual = 1;

}
