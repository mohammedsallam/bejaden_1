<?php

namespace App\Http\Controllers\Admin\pjitmmsfl;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class pjitmmsflController extends Controller
{
    public function index(){

    }
}
