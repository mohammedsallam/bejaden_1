<?php

namespace App\Http\Controllers\Admin\report;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class RDriverController extends Controller
{
    public function index(Request $request)
    {
        if($request->ajax()){

        }
    }
}
