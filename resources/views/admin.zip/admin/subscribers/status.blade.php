@if($Cstm_Active == 1)
    {{trans('admin.active')}}
    @else
    {{trans('admin.deactive')}}
@endif
